import asyncio
import json
import re
import sqlite3
from asyncio import sleep

from telethon import Button, events
from telethon.tl import functions, types
from telethon.tl.functions.messages import SendReactionRequest
from telethon.tl.types import ReactionEmoji, ReactionPaid

import stars
import admin
import config
import database
import order
import support
import membership
import order
import user
import start

bot = config.bot

#____________________ support _____________________
with bot as mirali :
    mirali.add_event_handler(support.support)

#___________________ admin ________________________
with bot as mirali :
    mirali.add_event_handler(admin.admin_panel)

#___________________ order ________________________
with bot as mirali :
    mirali.add_event_handler(order.increase)

#___________________ user ________________________
with bot as mirali :
    mirali.add_event_handler(user.account)

#___________________ stars ________________________
with bot as mirali :
    mirali.add_event_handler(stars.stars)

#___________________ start ________________________
with bot as mirali :
    mirali.add_event_handler(start.start)

#___________________ jsons ________________________
def create_json_files(file1, file2):
    data = {"message": "This is a sample JSON file."}

    with open(file1, "w", encoding="utf-8") as f1:
        json.dump(data, f1, ensure_ascii=False, indent=4)

    with open(file2, "w", encoding="utf-8") as f2:
        json.dump(data, f2, ensure_ascii=False, indent=4)

    print(f"✅ دو فایل {file1} و {file2} ایجاد شدند.")

file_name1 = "last_message.json"
file_name2 = "support_queue.json"

create_json_files(file_name1, file_name2)

loop = asyncio.get_event_loop()
bot.start()
print("run")
loop.run_forever()